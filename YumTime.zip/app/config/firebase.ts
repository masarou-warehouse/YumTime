// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
import { getAuth } from "firebase/auth";
// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC2BKPs6yzRvPrEK3S1cEUPo6qDpYTSzPM",
  authDomain: "yumtime-ffe68.firebaseapp.com",
  projectId: "yumtime-ffe68",
  storageBucket: "yumtime-ffe68.appspot.com",
  messagingSenderId: "810623940999",
  appId: "1:810623940999:web:c7c178ec00d9eeb762fb22"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);